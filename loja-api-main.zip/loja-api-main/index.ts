import { connect } from 'mongoose';
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { router } from './src/routes';
dotenv.config();

connect(`${process.env.DB_URL}`)  
  .then(() => console.log('Connected database'));

const app = express();

// Middlewares
app.use(cors());

// Rotas
app.use('/', router);

const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`App running on port ${port}`));

export default app;