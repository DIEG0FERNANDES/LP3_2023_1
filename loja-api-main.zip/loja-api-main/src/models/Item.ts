import mongoose, { Schema, Document } from 'mongoose';
import { IProduto } from './Produto';

export interface IItem extends Document {
  id: number;
  quantidade: number;
  dataChegadaNoEstoque: Date;
  produto: IProduto;
}

const schema = new Schema({
  id: {
    type: Number,
    required: true,
    unique: true,
  },
  quantidade: Number,
  dataChegadaNoEstoque: Date,
  produto: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Produto'
  }
});

const ItemModel = mongoose.model('Item', schema, 'itens');

export default ItemModel;