import mongoose, { Schema, Document } from 'mongoose';

export interface IProduto extends Document {
  id: number;
  descricao: string;
  perecivel: boolean;
}

const schema = new Schema<IProduto>({
  id: {
    type: Number,
    required: true,
    unique: true,
  },
  descricao: String,
  perecivel: Boolean
});

const ProdutoModel = mongoose.model('Produto', schema, 'produtos');

export default ProdutoModel;