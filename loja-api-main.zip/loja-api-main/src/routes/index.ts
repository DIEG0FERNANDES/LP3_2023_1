import express from 'express';
import ProdutoController from './../controllers/ProdutoController';
import ItemController from './../controllers/ItemController';

export const router = express.Router();
const produtoController = new ProdutoController();
const itemController = new ItemController();

router.post('/produtos', (req, res) => produtoController.save(req, res));
router.delete('/produtos/:id', (req, res) => produtoController.deleteById(req, res));
router.post('/itens', (req, res) => itemController.save(req, res));
router.post('/itens/produto/:produtoid', (req, res) => itemController.getItemsByProduct(req, res));