export class Cep {
  cep: string;
  logradouro: string;

  constructor(cep: string, logradouro: string) {
    this.cep = cep;
    this.logradouro = logradouro;
  }
}