export const TYPES = {
  DbConnector: Symbol.for('DbConnector'),
  ICepDAO: Symbol.for('ICepDAO')
};