type DatabaseType = 'mongodb' | 'postgres';

export default DatabaseType;