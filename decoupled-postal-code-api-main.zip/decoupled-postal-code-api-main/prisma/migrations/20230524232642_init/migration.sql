-- CreateTable
CREATE TABLE "Cep" (
    "id" TEXT NOT NULL,
    "cep" TEXT NOT NULL,
    "logradouro" TEXT NOT NULL,

    CONSTRAINT "Cep_pkey" PRIMARY KEY ("id")
);
